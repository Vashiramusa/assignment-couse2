class Assignment < ActiveRecord::Base
end
